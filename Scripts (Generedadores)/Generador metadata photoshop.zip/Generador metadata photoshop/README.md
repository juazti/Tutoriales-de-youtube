# hashlips_art_engine_ps_script
This script allows you to generate art works right from photoshop.


Keep in mind this script is experimental and still in development, but you can try it out in the meantime.
